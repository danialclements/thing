import pandas as pd



if __name__ == '__main__':
    df = pd.read_csv('./netflix_titles.csv')
    df.to_parquet('./netflix_titles.parquet')
