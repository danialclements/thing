from fastapi import FastAPI
from main import nodes

app = FastAPI()


@app.get('/api/v1/nodes')
def get_nodes():
    return {'nodes': [node.get_definition().dict() for node in nodes]}

@app.post('/api/v1/dataflow')
def save_dataflow():
    pass