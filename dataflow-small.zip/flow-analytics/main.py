import apache_beam as beam
from abc import ABC, abstractmethod
from apache_beam.options.pipeline_options import PipelineOptions

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Set, Literal
import logging

logging.basicConfig(level=logging.DEBUG)
LOGGER = logging.getLogger(__name__)


class NodeConnection(BaseModel):
    node_id: str
    port_id: str

# PyV6g7SthmhuexX
# u8FZHJLXfAyjP85
# vArrH2gJvBaMxU4

class Connection(BaseModel):
    source: NodeConnection
    destination: NodeConnection


class Port(BaseModel):
    id: str
    name: str


class DataflowNodePosition(BaseModel):
    x: int
    y: int


class DataflowNodeProperties(BaseModel):
    position: DataflowNodePosition


class DataflowNode(BaseModel):
    id: str
    name: str
    type: str
    inputs: Optional[List[Port]]
    outputs: Optional[List[Port]]
    properties: Dict

class DataflowViewport(BaseModel):
    x: int
    y: int
    zoom: int

class DataflowProperties(BaseModel):
    viewport: DataflowViewport

class Dataflow(BaseModel):
    id: str
    nodes: List[DataflowNode]
    connections: List[Connection]
    properties: DataflowProperties


"""
Node Types
Source
Destination
Transform
Group
Join
"""

# dataflow_1 = Dataflow(nodes=[
#     Node(id='source_1', type='source_read_from_parquet', outputs=[
#         Port(id='output_1', name='Output')
#     ])
# ])

json_string = """
{
  "id": "test",
  "nodes": [
    {
      "id": "source_1",
      "type": "source_read_from_parquet",
      "outputs": [
        {
          "id": "output_1"
        }
      ],
      "data": {
        "path": "/home/danial/projects/flow-analytics/netflix_titles.parquet"
      }
    },
    {
      "id": "transform_1",
      "type": "transform_filter_by_column",
      "inputs": [
        {
          "id": "input_1"
        }
      ],
      "outputs": [
        {
          "id": "output_1"
        }
      ],
      "data": {
        "column": "type",
        "value": "Movie"
      }
    },
    {
      "id": "destination_1",
      "type": "destination_write_to_file",
      "inputs": [
        {
          "id": "input_1"
        }
      ],
      "data": {
        "path": "/home/danial/projects/flow-analytics/movies.csv"
      }
    },
    {
      "id": "sample_1",
      "type": "debug_sample",
      "inputs": [
        {
          "id": "input_1"
        }
      ],
      "data": {
        "size": 10
      }
    }
  ],
  "connections": [
    {
      "source": {
        "node_id": "source_1",
        "port_id": "output_1"
      },
      "destination": {
        "node_id": "transform_1",
        "port_id": "input_1"
      }
    },
    {
      "source": {
        "node_id": "transform_1",
        "port_id": "output_1"
      },
      "destination": {
        "node_id": "destination_1",
        "port_id": "input_1"
      }
    },
    {
      "source": {
        "node_id": "source_1",
        "port_id": "output_1"
      },
      "destination": {
        "node_id": "sample_1",
        "port_id": "input_1"
      }
    }
  ]
}

"""

"""
Node Types
- Source
- Transformations
- Joins
- Group By
- Destination
- Aggregations

"""


class FilterByColumn(beam.DoFn):

    def __init__(self, column: str, value: str):
        self.column = column
        self.value = value

    def process(self, element):
        if self.column in element and element[self.column] == self.value:
            return [element]


class NodeProperty(BaseModel):
    name: str
    type: str


class NodeSchema(BaseModel):
    name: str
    type: str
    kind: str
    inputs: Optional[List[Port]] = Field([])
    outputs: Optional[List[Port]] = Field([])
    properties: Optional[List[NodeProperty]] = Field([])


class BaseNode(ABC):

    @staticmethod
    @abstractmethod
    def get_definition() -> NodeSchema:
        pass

    @staticmethod
    @abstractmethod
    def get_transformation(node: DataflowNode):
        pass


class SourceReadFromParquet(BaseNode):

    @staticmethod
    def get_definition():
        outputs = [
            Port(id='data', name='Data')
        ]
        properties = [
            NodeProperty(name='path', type='path')
        ]
        return NodeSchema(type='source_read_from_parquet', name='Read From Parquet', kind='Source', outputs=outputs, properties=properties)

    @staticmethod
    def get_transformation(node: DataflowNode):
        return f'{node.id}_parquet' >> beam.io.ReadFromParquet(node.data['path'])


class TransformFilterByColumn(BaseNode):

    @staticmethod
    def get_definition():
        inputs = [
            Port(id='input', name='Input')
        ]
        outputs = [
            Port(id='output', name='Output')
        ]
        properties = [
            NodeProperty(name='column', type='string'),
            NodeProperty(name='value', type='string'),
        ]
        return NodeSchema(type='transform_filter_by_column', name='Filter By Column', kind='Transform', inputs=inputs, outputs=outputs, properties=properties)

    @staticmethod
    def get_transformation(node: DataflowNode):
        return f'{node.id}_process' >> beam.ParDo(FilterByColumn(node.data['column'], node.data['value']))


class DestinationWriteToFile(BaseNode):

    @staticmethod
    def get_definition():
        inputs = [
            Port(id='input', name='Input')
        ]
        properties = [
            NodeProperty(name='path', type='string')
        ]
        return NodeSchema(type='destination_write_to_file', name='Write to File', kind='Destination', inputs=inputs, properties=properties)

    @staticmethod
    def get_transformation(node: DataflowNode):
        return f'{node.id}_write' >> beam.io.WriteToText(node.data['path'])


class DebugSample(BaseNode):

    @staticmethod
    def get_definition():
        inputs = [
            Port(id='Input', name='Input')
        ]
        properties = [
            NodeProperty(name='size', type='string')
        ]
        return NodeSchema(type='debug_sample', name='Sample', kind='Debug', inputs=inputs, properties=properties)

    @staticmethod
    def get_transformation(node: DataflowNode):
        size = node.data['size']
        return f'{node.id}_sample' >> beam.combiners.Sample.FixedSizeGlobally(size) | beam.Map(LOGGER.info)


class Combine(BaseNode):
    
    @staticmethod
    def get_definition():
        inputs = [
            Port(id='input_1', name='Input 1'),
            Port(id='input_2', name='Input 2')
        ]
        outputs = [
            Port(id='output_1', name='Output 1')
        ]
        properties = []
        return NodeSchema(type='combine', name='Combine', kind='Aggregation', inputs=inputs, outputs=outputs, properties=properties)

    @staticmethod
    def get_transformation(node: DataflowNode):
        size = node.data['size']
        return f'{node.id}_sample' >> beam.combiners.Sample.FixedSizeGlobally(size) | beam.Map(LOGGER.info)


class GroupByKey(BaseNode):
    
    @staticmethod
    def get_definition():
        inputs = [
            Port(id='input_1', name='Input 1'),
            Port(id='input_2', name='Input 2')
        ]
        outputs = [
            Port(id='output_1', name='Output 1')
        ]
        properties = []
        return NodeSchema(type='group_by_key', name='Group By Key', kind='Aggregation', inputs=inputs, outputs=outputs, properties=properties)

    @staticmethod
    def get_transformation(node: DataflowNode):
        size = node.data['size']
        return f'{node.id}_sample' >> beam.combiners.Sample.FixedSizeGlobally(size) | beam.Map(LOGGER.info)

nodes = [
    SourceReadFromParquet,
    TransformFilterByColumn,
    DestinationWriteToFile,
    DebugSample,
    Combine,
    GroupByKey
]


class DataflowRunner:

    def __init__(self, dataflow: Dataflow):
        self.dataflow = dataflow
        self.graph = self.build_graph(dataflow)
        self.pcollections = {}
        self.operator_map: Dict[str, BaseNode] = {
            node.get_definition().id: node for node in nodes}
        self.pipeline = self.build_pipeline()

    def create_pipeline(self):
        pipeline_options = PipelineOptions()
        return beam.Pipeline(options=pipeline_options)

    def execute(self):
        self.pipeline.run().wait_until_finish()

    def create_pcoll_for_node(self, node: DataflowNode, parent: DataflowNode):
        source_pcollection = self.pcollections[parent.id]
        self.pcollections[node.id] = source_pcollection | self.get_operator_for_node(
            node)

        next_nodes = self.graph[node.id]

        for next_node in next_nodes:
            self.create_pcoll_for_node(next_node, node)

    def get_operator_for_node(self, node: DataflowNode):
        if node.type in self.operator_map:
            return self.operator_map[node.type].get_transformation(node)
        else:
            raise Exception(f'Unknown node type {node.type}')

    def build_pipeline(self):
        pipeline = self.create_pipeline()
        for node in dataflow.nodes:
            if node.type.startswith('source'):
                self.pcollections[node.id] = pipeline | self.get_operator_for_node(
                    node)
                next_nodes = self.graph[node.id]

                for next_node in next_nodes:
                    self.create_pcoll_for_node(next_node, node)

        return pipeline

    def build_graph(self, dataflow: Dataflow) -> Dict[str, List[DataflowNode]]:
        """Builds a graph for all the connections within a dataflow"""
        graph = {}
        nodes_map = {node.id: node for node in dataflow.nodes}
        for node in dataflow.nodes:
            graph[node.id] = []

        for connection in dataflow.connections:
            graph[connection.source.node_id].append(
                nodes_map[connection.destination.node_id])

        return graph


if __name__ == '__main__':
    dataflow = Dataflow.parse_raw(json_string)
    runner = DataflowRunner(dataflow)
    runner.execute()
