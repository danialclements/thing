import React from "react";
import './Panel.component.scss';

interface PanelProps {
    title: string;
    isClosed?: boolean;
    children: React.ReactNode;
}

const Panel: React.FC<PanelProps> = (props) => {
    const {title, isClosed, children} = props;
    return <div className='panel-container'>
        <div className="panel-header">{title}</div>
        <div className="panel-content">{children}</div>
    </div>
}

export default Panel;
