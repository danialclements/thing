import React from "react";
import Panel from "../../Panel.component";
import './DataflowSelectionSidebar.component.scss';

const DataflowSelectionSidebar: React.FC = (props) => {
    const test = [
        [<div>test</div>, <div>test</div>],
        [<div>test</div>, <div>test</div>],
    ]
    return <div className="sidebar">
        {test}
    </div>
}

export default DataflowSelectionSidebar;
