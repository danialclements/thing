import { SaveSVGIcon, PlayArrowSVGIcon } from "@react-md/material-icons";
import { MouseEvent } from "react";
import "./DataflowEditorToolbar.component.scss";

interface DataflowEditorToolbarProps {
  onToolbarAction: (action: string) => void;
}

const DataflowEditorToolbar: React.FC<DataflowEditorToolbarProps> = (props) => {
  const { onToolbarAction } = props;
  
  const handleButtonPress = (action: string) => {
    return (event: MouseEvent) => onToolbarAction(action);
  }


  return (
    <div className="toolbar">
      <button className="toolbar-action" onClick={handleButtonPress('save')}>
        <SaveSVGIcon className="icon" /> Save
      </button>
      <button className="toolbar-action" onClick={handleButtonPress('run-dataflow')}>
        <PlayArrowSVGIcon className="icon" /> Run Dataflow
      </button>
    </div>
  );
};

export default DataflowEditorToolbar;
