import React, {
  useCallback,
  useMemo,
  MouseEvent,
  useState,
  DragEvent,
  useRef,
  useEffect,
} from "react";
import ReactFlow, {
  useNodesState,
  useEdgesState,
  addEdge,
  Controls,
  MiniMap,
  Background,
  BackgroundVariant,
  ReactFlowProvider,
  Handle,
  Position,
  Node,
  NodeMouseHandler,
  Edge,
  NodeChange,
  ReactFlowInstance,
} from "reactflow";

import { InputSVGIcon } from "@react-md/material-icons";

import "reactflow/dist/style.css";

import "./DataflowEditor.component.scss";
import DataflowEditorToolbar from "./Dataflow/DataflowEditorToolbar/DataflowEditorToolbar.component";
import DataflowSelectionSidebar from "./Dataflow/DataflowSelectionSidebar/DataflowSelectionSidebar.component";
import Panel from "./Panel.component";

interface NodeConnection {
  node_id: string;
  port_id: string;
}

interface Connection {
  source: NodeConnection;
  destination: NodeConnection;
}

interface Port {
  id: string;
  name: string;
}

interface DataflowNodeProperties {
  position: {x: number, y: number};
  custom?: any;
}

interface DataflowProperties {
  viewport: { x: number, y: number, zoom: number }
}

interface DataflowNode {
  id: string;
  name: string;
  type: string;
  inputs?: Port[];
  outputs?: Port[];
  properties: DataflowNodeProperties;
}

interface Dataflow {
  id: string;
  nodes: DataflowNode[];
  connections: Connection[];
  properties: DataflowProperties;
}

interface PortSchema {
  id: string;
  name: string;
}

interface NodeSchema {
  type: string;
  name: string;
  kind: string;
  inputs: PortSchema[];
  outputs: PortSchema[];
  properties: any;
}

function DataflowNode(props: any) {
  const node = props.data.node as DataflowNode;
  const onChange = useCallback((evt: any) => {
    console.log(evt.target.value);
  }, []);

  const inputs = (node.inputs || []).map((input) => {
    return (
      <div className="node-input" key={input.id}>
        <Handle
          type="target"
          position={Position.Left}
          id={input.id}
          className="node-handle"
        />
        {input.name}
      </div>
    );
  });

  const outputs = (node.outputs || []).map((output) => {
    return (
      <div className="node-input" key={output.id}>
        <Handle
          type="source"
          position={Position.Right}
          id={output.id}
          isConnectable={true}
          className="node-handle"
        />
        {output.name}
      </div>
    );
  });

  return (
    <>
      <div className="node">
        <div className="node-header">
          <InputSVGIcon className="icon" />
          {node.name}
        </div>
        <div className="node-content">
          <div className="node-inputs">{inputs}</div>
          <div className="node-outputs">{outputs}</div>
        </div>
      </div>
    </>
  );
}

interface DataflowEditorSidebarProps {
  nodesSchema: NodeSchema[];
}

const DataflowEditorSidebar: React.FC<DataflowEditorSidebarProps> = (props) => {
  const { nodesSchema } = props;
  const dragHandler = (node: NodeSchema) => {
    return (event: DragEvent) => {
      event.dataTransfer.setData("application/reactflow", node.type);
      event.dataTransfer.effectAllowed = "move";
    };
  };

  const groups = nodesSchema.reduce<{ [key: string]: NodeSchema[] }>(
    (groups, node) => {
      if (node.kind in groups) {
        groups[node.kind].push(node);
      } else {
        groups[node.kind] = [node];
      }
      return groups;
    },
    {}
  );

  const sidebarNodes = Object.entries(groups).map((entry) => {
    const groupName = entry[0];
    const items = entry[1];
    const nodes = items.map(item => {
      return (
        <div
          className="sidebar-node"
          key={item.type}
          onDragStart={dragHandler(item)}
          draggable
        >
          {item.name}
        </div>
      );
    });
    return <Panel key={groupName} title={groupName}>
      {nodes}
    </Panel>
    
  });

  return <div>{sidebarNodes}</div>;
};

const dataflow: Dataflow = {
  id: "test",
  nodes: [
    {
      id: "source_1",
      name: "Netflix Titles",
      type: "source",
      outputs: [
        {
          id: "output_1",
          name: "Output",
        },
      ],
      properties: {
        position: {
          x: 0,
          y: 0
        },
        custom: {
          path: "/home/danial/projects/flow-analytics/netflix_titles.parquet",
        }
      },
    },
    {
      id: "transform_1",
      name: "Filter By Column",
      type: "transformation",
      inputs: [
        {
          id: "input_1",
          name: "Input",
        },
      ],
      outputs: [
        {
          id: "output_1",
          name: "Output",
        },
      ],
      properties: {
        position: {
          x: 252,
          y: -14
        },
        custom: {
          function: "filter_by_column",
        }
      },
    },
    {
      id: "destination_1",
      name: "Write to movies.csv",
      type: "destination",
      inputs: [
        {
          id: "input_1",
          name: "Input",
        },
      ],
      properties: {
        position: {
          x: 478,
          y: -8
        },
        custom: {
          path: "/home/danial/projects/flow-analytics/movies.csv",
        }
      },
    },
    {
      id: "sample_1",
      name: "Sample Output",
      type: "sample",
      inputs: [
        {
          id: "input_1",
          name: "Input",
        },
      ],
      properties: {
        position: {
          x: 252,
          y: 84
        },
        custom: {
          size: 10
        }
      },
    },
  ],
  connections: [
    {
      source: {
        node_id: "source_1",
        port_id: "output_1",
      },
      destination: {
        node_id: "transform_1",
        port_id: "input_1",
      },
    },
    {
      source: {
        node_id: "transform_1",
        port_id: "output_1",
      },
      destination: {
        node_id: "destination_1",
        port_id: "input_1",
      },
    },
    {
      source: {
        node_id: "source_1",
        port_id: "output_1",
      },
      destination: {
        node_id: "sample_1",
        port_id: "input_1",
      },
    },
  ],
  properties: {
    viewport: { x: 355, y: 227, zoom: 1 }
  }
};

const generateId = (prefix: string = "id") => {
  return `${prefix}_${Math.floor(Date.now() * Math.random()).toString(16)}`;
};

const edgeStyle = {
  stroke: "#999999",
  strokeWidth: "3px",
};

const parseDataflowToNodesAndEdges = (
  dataflow: Dataflow
): { nodes: Node[]; edges: Edge[] } => {
  const nodes: Node[] = dataflow.nodes.map((node, index) => {
    const { id } = node;
    const data = { node };
    const type = "dataflowNode";
    const { x, y } = node.properties.position;
    return { id, type, data, position: { x, y } };
  });
  const edges: Edge[] = dataflow.connections.map((connection) => {
    const id = generateId();
    const source = connection.source.node_id;
    const sourceHandle = connection.source.port_id;
    const target = connection.destination.node_id;
    const targetHandle = connection.destination.port_id;
    return { id, source, sourceHandle, target, targetHandle, style: edgeStyle };
  });

  return { nodes, edges };
};

const updateDataflow = (dataflow: Dataflow, nodes: Node[], edges: Edge[]) => {
  console.log(dataflow, nodes, edges);
};

const api = {
  getNodeSchema: () => {
    return fetch("/api/v1/nodes").then((res) => res.json());
  },
  saveDataflow: (dataflow: Dataflow) => {
    return fetch("/api/v1/dataflow", { method: "POST" }).then((res) =>
      res.json()
    );
  },
};

const debounce = (fn: Function, timeout: number = 300) => {
  let timer: NodeJS.Timeout;
  return (...args: any[]) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      fn.apply(this, args);
    }, timeout);
  };
};

const useDebounce = (fn: CallableFunction, timeout: number = 300) => {
  const ref = useRef<CallableFunction>();

  useEffect(() => {
    ref.current = fn;
  }, [fn]);

  const debouncedCallback = useMemo(() => {
    const func = () => {
      ref.current?.();
    };

    return debounce(func, timeout);
  }, []);

  return debouncedCallback;
};

const DataflowEditor: React.FC = () => {
  const [nodesSchema, setNodesSchema] = useState<NodeSchema[]>([]);
  const parsedDataFlow = parseDataflowToNodesAndEdges(dataflow);
  const [nodes, setNodes, onNodesChange] = useNodesState(parsedDataFlow.nodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(parsedDataFlow.edges);
  const reactFlowWrapper = useRef<HTMLDivElement>(null);
  const nodeTypes = useMemo(() => ({ dataflowNode: DataflowNode }), []);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [reactFlowInstance, setReactFlowInstance] =
    useState<ReactFlowInstance | null>(null);

  useEffect(() => {
    api.getNodeSchema().then((data) => setNodesSchema(data.nodes));
  }, []);

  const onConnect = useCallback(
    (params: any) => {
      params.style = edgeStyle;
      return setEdges((eds) => addEdge(params, eds));
    },
    [setEdges]
  );

  const onDataflowUpdated = useDebounce(() => {
    if (!reactFlowInstance) {
      return;
    }

    updateDataflow(
      dataflow,
      reactFlowInstance.getNodes(),
      reactFlowInstance.getEdges()
    );
  }, 1000);

  const handleNodesChange = useCallback(
    (nodeChangeEvent: NodeChange[]) => {
      onDataflowUpdated();
      onNodesChange(nodeChangeEvent);
    },
    [onNodesChange]
  );

  const onNodeClick: NodeMouseHandler = (event: MouseEvent, node: Node) => {
    setSelectedNode(node);
  };

  const onPaneClick = (event: MouseEvent) => {
    setSelectedNode(null);
  };

  const onDragOver = useCallback((event: DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const createNodeFromSchema = (nodeSchema: NodeSchema): DataflowNode => {
    return {
      id: generateId(),
      name: nodeSchema.name,
      type: nodeSchema.type,
      inputs: nodeSchema.inputs,
      outputs: nodeSchema.outputs,
      // TODO add properties from node
      properties: {
        position: {x: 0, y: 0}
      },
    };
  };

  const onDrop = useCallback(
    (event: DragEvent) => {
      event.preventDefault();
      if (!reactFlowWrapper.current || !reactFlowInstance) {
        return;
      }

      const reactFlowBounds = reactFlowWrapper.current.getBoundingClientRect();
      const type = event.dataTransfer.getData("application/reactflow");

      // check if the dropped element is valid
      if (typeof type === "undefined" || !type) {
        return;
      }

      const targetNodeSchema = nodesSchema.find((n) => n.type === type);
      if (!targetNodeSchema) {
        console.warn(`Could not find a type for ${type}`);
        return;
      }

      const position = reactFlowInstance.project({
        x: event.clientX - reactFlowBounds.left,
        y: event.clientY - reactFlowBounds.top,
      });

      const newNode = {
        id: generateId(),
        type: "dataflowNode",
        position,
        data: { node: createNodeFromSchema(targetNodeSchema) },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [reactFlowInstance, nodesSchema]
  );

  const onInit = (instance: any) => {
    setReactFlowInstance(instance);
    instance.setViewport(dataflow.properties.viewport);
  };

  const onToolbarAction = (action: string) => {
    switch (action) {
      case "save":
        console.log("saving");
    }
  };

  return (
    <div className="dataflow-editor" style={{ width: "100%", height: "100%" }}>
      <div className="left-sidebar">
        <DataflowEditorSidebar nodesSchema={nodesSchema} />
      </div>
      <div className="editor">
        <div className="editor-toolbar">
          <DataflowEditorToolbar onToolbarAction={onToolbarAction} />
        </div>
        <div className="editor-content" ref={reactFlowWrapper}>
          <ReactFlowProvider>
            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={handleNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              nodeTypes={nodeTypes}
              onInit={onInit}
              onDrop={onDrop}
              onDragOver={onDragOver}
              onNodeClick={onNodeClick}
              onPaneClick={onPaneClick}
              connectionLineStyle={edgeStyle}
              proOptions={{ hideAttribution: true }}
            />
          </ReactFlowProvider>
        </div>
      </div>
      <div className="right-sidebar">
        <DataflowSelectionSidebar />
      </div>
    </div>
  );
};

export default DataflowEditor;
