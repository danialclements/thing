import React from 'react';
import './App.scss';
import DataflowEditor from './DataflowEditor.component';

function App() {
  return (
    <div className="app">
      <div className="header">
        App Header
      </div>
      <div className="content">
        <DataflowEditor />
      </div>
    </div>
  );
}

export default App;
